All changes are welcome as long as no code is involved. If you run into any bugs, please file an issue and explain how that was even possible.
